import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactApiService {

  constructor(private http: HttpClient) { }

  url = `https://my-json-server.typicode.com/voramahavir/contacts-mock-response/contacts`;

  // getContacts() {

  // }

  getContacts(): Observable<[]> {
    const result = this.http.get<[]>(this.url);
    console.log('result', result);
    return this.http.get<[]>(this.url)
  }

}
